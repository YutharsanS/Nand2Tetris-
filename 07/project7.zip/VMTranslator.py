#!/usr/bin/env python

import argparse
import os

class Parser:
    def __init__(self, file_name):
        """
        Stores the original file and the array
        """
        self.file = open(file_name, 'r')
        self.final = self.file.readlines()

    def filterLines(self):
        self.final = list(filter(None, self.final))

    def handleComments(self):
        list_p = []

        for line in self.final:
            ind = line.find("//")

            if ind >= 0:
                list_p.append(line[: ind].strip())
            else:
                list_p.append(line.strip())

        self.final = list_p

    def returnFile(self):

        self.handleComments()
        self.filterLines()

        return self.final

class VMtranslator:
    def __init__(self, array, name):
        self.array = array
        self.result = []
        self.name = name
        self.lable = 0

    def expressLine(self, line):
    # returns a tuple with necessary elements
        elmnts = line.split()
        return tuple(elmnts)

    def processLine(self, tupl):

        if len(tupl) == 1:
            self.arithmaticLogical(*tupl)
        else:
            self.stackOperations(*tupl)

    def main(self):
        for line in self.array:
            self.processLine(self.expressLine(line))

        return self.result

    def arithmaticLogical(self, command):
        if command in ("eq", "lt", "gt", "and", "or", "add", "sub"):
            self.result.extend( [
                f"//{command}",
                '@SP',
                'M=M-1',
                'A=M',
                'D=M',
                '@SP',
                'M=M-1',
                'A=M',
            ])


            if command == "eq":
                self.logicalCommands(command)
            elif command == "lt":
                self.logicalCommands(command)
            elif command == "gt":
                self.logicalCommands(command)
            elif command == "and":
                self._and()
            elif command == "or":
                self._or()
            elif command == "add":
                self._add()
            elif command == "sub":
                self._sub()

            if command in ("and", "or", "add", "sub"):
                self.result.extend( [
                    'M=D',
                    '@SP',
                    'M=M+1'
                ])
            elif command in ('lt', 'gt', 'eq'):
                self.result.extend( [
                    '@SP',
                    'M=M+1'
                ])
        else:
            self.result.extend([
                f"//{command}",
                '@SP',
                'A=M-1'
            ])


            if command == 'neg':
                self._neg()
            elif command == 'not':
                self._not()

            self.result.extend([

            ])

    def logicalCommands(self, command):
        if command in ('eq', 'gt', 'lt'):
            self.result.extend(["D=M-D"])

            self.result.extend([
                f"@TRUE{self.lable}",
                f"D;{self.returnJump(command)}",
                f"@FALSE{self.lable}",
                f"0;JMP",
                f"(TRUE{self.lable})",
                f"@SP",
                f"A=M",
                f"M=-1",
                f"@MAIN{self.lable}",
                f"0;JMP",
                f"(FALSE{self.lable})",
                f"@SP",
                f"A=M",
                f"M=0",
                f"@MAIN{self.lable}",
                f"0;JMP",
                f"(MAIN{self.lable})"
            ])

            self.lable += 1

    def returnJump(self, command):
        if command == 'eq':
            return 'JEQ'
        elif command == 'gt':
            return 'JGT'
        elif command == 'lt':
            return 'JLT'

    def stackOperations(self, command, arg1, arg2):
        self.result.extend([f"//{command} {arg1} {arg2}"])

        if command != 'pointer':
            self.result.extend([
                f"@{arg2}",
                "D=A"
            ])

        if arg1 == 'constant':
            pass
        elif arg1 == 'local':
            self.result.extend(['@LCL'])
        elif arg1 == 'argument':
            self.result.extend(['@ARG'])
        elif arg1 == 'this':
            self.result.extend(['@THIS'])
        elif arg1 == 'that':
            self.result.extend(['@THAT'])
        elif arg1 == 'pointer':
            if arg2 == '0':
                self.result.extend(['@THIS'])
                self.result.extend(['D=M'])
            elif arg2 == '1':
                self.result.extend(['@THAT'])
                self.result.extend(['D=M'])
        elif arg1 == 'static':
            self.result.extend([f"@{self.name}.{arg2}"])
            self.result.extend(['D=M'])

        if arg1 == 'temp':
            self.result.extend([
                '@5',
                f"A=A+D",
                'D=M'
            ])

        if arg1 not in ('constant', 'pointer', 'static', 'temp'):
            self.result.extend([
                f"A=M+D",
                'D=M'
            ])

        if command == "push":
            self.result.extend([
                '@SP',
                'A=M',
                'M=D',
                '@SP',
                'M=M+1'
            ])

        elif command == "pop":
            self.result.extend([
                'D=A',
                '@R13',
                'M=D',
                '@SP',
                'M=M-1',
                'A=M',
                'D=M',
                '@R13',
                'A=M',
                'M=D'
            ])

    # Start of  Logical commands
    def _and(self):
        self.result.extend(['D=D&M'])
    def _or(self):
        self.result.extend(['D=D|M'])
    def _not(self):
        self.result.extend(['M=!M'])

    # Start of Arithmatic commands
    def _add(self):
        self.result.extend(['D=D+M'])
    def _sub(self):
        self.result.extend(['D=M-D'])
    def _neg(self):
        self.result.extend(['M=-M'])


def main():
    parser = argparse.ArgumentParser(
        description="Translate VM Code to Hack Assembly Code"
    )
    parser.add_argument("vm", help="filepath of VM code")
    args = parser.parse_args()

    filepath: str = args.vm
    assert filepath.endswith(".vm"), f"{filepath} doesn't end with .vm"

    name = filepath.split("/")[-1].split(".")[0]

    output: str = filepath.rstrip(".vm") + ".asm"

    code = Parser(filepath).returnFile()
    translator = VMtranslator(code, name)
    final = translator.main()

    with open(output, 'w') as file:
        print(*final, sep='\n', file=file)

main()